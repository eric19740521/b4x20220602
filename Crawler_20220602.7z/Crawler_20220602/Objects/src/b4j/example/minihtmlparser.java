package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class minihtmlparser extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.minihtmlparser", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.minihtmlparser.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public int _index = 0;
public String _mhtml = "";
public String _whitespace = "";
public b4j.example.b4xset _voidtags = null;
public b4j.example.minihtmlparser._htmlnode _nonode = null;
public anywheresoftware.b4a.objects.collections.Map _escapedentitiesmap = null;
public b4j.example.main _main = null;
public b4j.example.b4xcollections _b4xcollections = null;
public b4j.example.httputils2service _httputils2service = null;
public static class _htmlnode{
public boolean IsInitialized;
public String Name;
public anywheresoftware.b4a.objects.collections.List Children;
public anywheresoftware.b4a.objects.collections.List Attributes;
public boolean Closed;
public b4j.example.minihtmlparser._htmlnode Parent;
public void Initialize() {
IsInitialized = true;
Name = "";
Children = new anywheresoftware.b4a.objects.collections.List();
Attributes = new anywheresoftware.b4a.objects.collections.List();
Closed = false;
Parent = new b4j.example.minihtmlparser._htmlnode();
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _htmlattribute{
public boolean IsInitialized;
public String Key;
public String Value;
public void Initialize() {
IsInitialized = true;
Key = "";
Value = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Type HtmlNode (Name As String, Children As List,";
;
 //BA.debugLineNum = 3;BA.debugLine="Type HtmlAttribute (Key As String, Value As Strin";
;
 //BA.debugLineNum = 4;BA.debugLine="Private Index As Int";
_index = 0;
 //BA.debugLineNum = 5;BA.debugLine="Private mHtml As String";
_mhtml = "";
 //BA.debugLineNum = 6;BA.debugLine="Private WhiteSpace As String = \" \" & TAB & Chr(10";
_whitespace = " "+__c.TAB+BA.ObjectToString(__c.Chr((int) (10)))+BA.ObjectToString(__c.Chr((int) (13)));
 //BA.debugLineNum = 7;BA.debugLine="Private VoidTags As B4XSet";
_voidtags = new b4j.example.b4xset();
 //BA.debugLineNum = 8;BA.debugLine="Public NoNode As HtmlNode";
_nonode = new b4j.example.minihtmlparser._htmlnode();
 //BA.debugLineNum = 9;BA.debugLine="Public EscapedEntitiesMap As Map";
_escapedentitiesmap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public String  _closeelement(b4j.example.minihtmlparser._htmlnode _parent) throws Exception{
int _start = 0;
String _name = "";
b4j.example.minihtmlparser._htmlnode _correctparent = null;
b4j.example.minihtmlparser._htmlnode _p = null;
 //BA.debugLineNum = 56;BA.debugLine="Private Sub CloseElement (Parent As HtmlNode)";
 //BA.debugLineNum = 57;BA.debugLine="Dim start As Int = Index + 1";
_start = (int) (_index+1);
 //BA.debugLineNum = 58;BA.debugLine="ReadUntil(\">\")";
_readuntil(">");
 //BA.debugLineNum = 59;BA.debugLine="Dim name As String = mHtml.SubString2(start, Inde";
_name = _mhtml.substring(_start,(int) (_index-1)).trim();
 //BA.debugLineNum = 60;BA.debugLine="Parent.Closed = True";
_parent.Closed /*boolean*/  = __c.True;
 //BA.debugLineNum = 61;BA.debugLine="If name <> Parent.Name Then";
if ((_name).equals(_parent.Name /*String*/ ) == false) { 
 //BA.debugLineNum = 62;BA.debugLine="Dim CorrectParent As HtmlNode";
_correctparent = new b4j.example.minihtmlparser._htmlnode();
 //BA.debugLineNum = 63;BA.debugLine="Dim p As HtmlNode = Parent.Parent";
_p = _parent.Parent /*b4j.example.minihtmlparser._htmlnode*/ ;
 //BA.debugLineNum = 64;BA.debugLine="Do While p.IsInitialized";
while (_p.IsInitialized /*boolean*/ ) {
 //BA.debugLineNum = 65;BA.debugLine="If p.Name = name Then";
if ((_p.Name /*String*/ ).equals(_name)) { 
 //BA.debugLineNum = 66;BA.debugLine="CorrectParent = p";
_correctparent = _p;
 //BA.debugLineNum = 67;BA.debugLine="Exit";
if (true) break;
 };
 //BA.debugLineNum = 69;BA.debugLine="p = p.Parent";
_p = _p.Parent /*b4j.example.minihtmlparser._htmlnode*/ ;
 }
;
 //BA.debugLineNum = 71;BA.debugLine="If CorrectParent.IsInitialized Then";
if (_correctparent.IsInitialized /*boolean*/ ) { 
 //BA.debugLineNum = 72;BA.debugLine="CorrectParent.Closed = True";
_correctparent.Closed /*boolean*/  = __c.True;
 //BA.debugLineNum = 73;BA.debugLine="Dim p As HtmlNode = Parent.Parent";
_p = _parent.Parent /*b4j.example.minihtmlparser._htmlnode*/ ;
 //BA.debugLineNum = 74;BA.debugLine="Do While p <> CorrectParent";
while ((_p).equals(_correctparent) == false) {
 //BA.debugLineNum = 75;BA.debugLine="p.Closed = True";
_p.Closed /*boolean*/  = __c.True;
 //BA.debugLineNum = 76;BA.debugLine="p = p.Parent";
_p = _p.Parent /*b4j.example.minihtmlparser._htmlnode*/ ;
 }
;
 };
 };
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return "";
}
public b4j.example.minihtmlparser._htmlattribute  _createhtmlattribute(String _key,String _value) throws Exception{
b4j.example.minihtmlparser._htmlattribute _t1 = null;
 //BA.debugLineNum = 211;BA.debugLine="Public Sub CreateHtmlAttribute (Key As String, Val";
 //BA.debugLineNum = 212;BA.debugLine="Dim t1 As HtmlAttribute";
_t1 = new b4j.example.minihtmlparser._htmlattribute();
 //BA.debugLineNum = 213;BA.debugLine="t1.Initialize";
_t1.Initialize();
 //BA.debugLineNum = 214;BA.debugLine="t1.Key = Key";
_t1.Key /*String*/  = _key;
 //BA.debugLineNum = 215;BA.debugLine="t1.Value = Value";
_t1.Value /*String*/  = _value;
 //BA.debugLineNum = 216;BA.debugLine="Return t1";
if (true) return _t1;
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
return null;
}
public b4j.example.minihtmlparser._htmlnode  _createhtmlnode(String _name,b4j.example.minihtmlparser._htmlnode _parent) throws Exception{
b4j.example.minihtmlparser._htmlnode _t1 = null;
 //BA.debugLineNum = 201;BA.debugLine="Private Sub CreateHtmlNode (Name As String, Parent";
 //BA.debugLineNum = 202;BA.debugLine="Dim t1 As HtmlNode";
_t1 = new b4j.example.minihtmlparser._htmlnode();
 //BA.debugLineNum = 203;BA.debugLine="t1.Initialize";
_t1.Initialize();
 //BA.debugLineNum = 204;BA.debugLine="t1.Name = Name";
_t1.Name /*String*/  = _name;
 //BA.debugLineNum = 205;BA.debugLine="t1.Children.Initialize";
_t1.Children /*anywheresoftware.b4a.objects.collections.List*/ .Initialize();
 //BA.debugLineNum = 206;BA.debugLine="t1.Attributes.Initialize";
_t1.Attributes /*anywheresoftware.b4a.objects.collections.List*/ .Initialize();
 //BA.debugLineNum = 207;BA.debugLine="t1.Parent = Parent";
_t1.Parent /*b4j.example.minihtmlparser._htmlnode*/  = _parent;
 //BA.debugLineNum = 208;BA.debugLine="Return t1";
if (true) return _t1;
 //BA.debugLineNum = 209;BA.debugLine="End Sub";
return null;
}
public b4j.example.minihtmlparser._htmlnode  _createtextnode(b4j.example.minihtmlparser._htmlnode _parent,boolean _addspaceatbeginning) throws Exception{
b4j.example.minihtmlparser._htmlnode _textnode = null;
int _start = 0;
String _value = "";
 //BA.debugLineNum = 82;BA.debugLine="Private Sub CreateTextNode (Parent As HtmlNode, Ad";
 //BA.debugLineNum = 83;BA.debugLine="Dim TextNode As HtmlNode = CreateHtmlNode(\"text\",";
_textnode = _createhtmlnode("text",_parent);
 //BA.debugLineNum = 84;BA.debugLine="Dim start As Int = Index - 1";
_start = (int) (_index-1);
 //BA.debugLineNum = 85;BA.debugLine="ReadUntil(\"<\")";
_readuntil("<");
 //BA.debugLineNum = 86;BA.debugLine="If Index < mHtml.Length Then";
if (_index<_mhtml.length()) { 
 //BA.debugLineNum = 87;BA.debugLine="Index = Index - 1";
_index = (int) (_index-1);
 };
 //BA.debugLineNum = 89;BA.debugLine="Dim value As String = mHtml.SubString2(start, Ind";
_value = _mhtml.substring(_start,_index);
 //BA.debugLineNum = 90;BA.debugLine="If AddSpaceAtBeginning Then value = \" \" & value";
if (_addspaceatbeginning) { 
_value = " "+_value;};
 //BA.debugLineNum = 91;BA.debugLine="TextNode.Attributes.Add(CreateHtmlAttribute(\"valu";
_textnode.Attributes /*anywheresoftware.b4a.objects.collections.List*/ .Add((Object)(_createhtmlattribute("value",_value)));
 //BA.debugLineNum = 92;BA.debugLine="Return TextNode";
if (true) return _textnode;
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _finddirectnodes(b4j.example.minihtmlparser._htmlnode _root,String _tagname,b4j.example.minihtmlparser._htmlattribute _attribute) throws Exception{
anywheresoftware.b4a.objects.collections.List _res = null;
b4j.example.minihtmlparser._htmlnode _child = null;
 //BA.debugLineNum = 246;BA.debugLine="Public Sub FindDirectNodes (Root As HtmlNode, TagN";
 //BA.debugLineNum = 247;BA.debugLine="Dim res As List";
_res = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 248;BA.debugLine="res.Initialize";
_res.Initialize();
 //BA.debugLineNum = 249;BA.debugLine="For Each child As HtmlNode In Root.Children";
{
final anywheresoftware.b4a.BA.IterableList group3 = _root.Children /*anywheresoftware.b4a.objects.collections.List*/ ;
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_child = (b4j.example.minihtmlparser._htmlnode)(group3.Get(index3));
 //BA.debugLineNum = 250;BA.debugLine="If IsNodeMatches(child, TagName, Attribute) Then";
if (_isnodematches(_child,_tagname,_attribute)) { 
 //BA.debugLineNum = 251;BA.debugLine="res.Add(child)";
_res.Add((Object)(_child));
 };
 }
};
 //BA.debugLineNum = 254;BA.debugLine="Return res";
if (true) return _res;
 //BA.debugLineNum = 255;BA.debugLine="End Sub";
return null;
}
public b4j.example.minihtmlparser._htmlnode  _findnode(b4j.example.minihtmlparser._htmlnode _root,String _tagname,b4j.example.minihtmlparser._htmlattribute _attribute) throws Exception{
b4j.example.minihtmlparser._htmlnode _child = null;
b4j.example.minihtmlparser._htmlnode _res = null;
 //BA.debugLineNum = 234;BA.debugLine="Public Sub FindNode (Root As HtmlNode, TagName As";
 //BA.debugLineNum = 235;BA.debugLine="If IsNodeMatches(Root, TagName, Attribute) Then";
if (_isnodematches(_root,_tagname,_attribute)) { 
 //BA.debugLineNum = 236;BA.debugLine="Return Root";
if (true) return _root;
 };
 //BA.debugLineNum = 238;BA.debugLine="For Each child As HtmlNode In Root.Children";
{
final anywheresoftware.b4a.BA.IterableList group4 = _root.Children /*anywheresoftware.b4a.objects.collections.List*/ ;
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_child = (b4j.example.minihtmlparser._htmlnode)(group4.Get(index4));
 //BA.debugLineNum = 239;BA.debugLine="Dim res As HtmlNode = FindNode(child, TagName, A";
_res = _findnode(_child,_tagname,_attribute);
 //BA.debugLineNum = 240;BA.debugLine="If res.IsInitialized Then Return res";
if (_res.IsInitialized /*boolean*/ ) { 
if (true) return _res;};
 }
};
 //BA.debugLineNum = 242;BA.debugLine="Return NoNode";
if (true) return _nonode;
 //BA.debugLineNum = 243;BA.debugLine="End Sub";
return null;
}
public String  _getattributevalue(b4j.example.minihtmlparser._htmlnode _node,String _key,String _defaultvalue) throws Exception{
b4j.example.minihtmlparser._htmlattribute _at = null;
 //BA.debugLineNum = 281;BA.debugLine="Public Sub GetAttributeValue(Node As HtmlNode, Key";
 //BA.debugLineNum = 282;BA.debugLine="For Each at As HtmlAttribute In Node.Attributes";
{
final anywheresoftware.b4a.BA.IterableList group1 = _node.Attributes /*anywheresoftware.b4a.objects.collections.List*/ ;
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_at = (b4j.example.minihtmlparser._htmlattribute)(group1.Get(index1));
 //BA.debugLineNum = 283;BA.debugLine="If at.Key = Key Then Return at.Value";
if ((_at.Key /*String*/ ).equals(_key)) { 
if (true) return _at.Value /*String*/ ;};
 }
};
 //BA.debugLineNum = 285;BA.debugLine="Return DefaultValue";
if (true) return _defaultvalue;
 //BA.debugLineNum = 286;BA.debugLine="End Sub";
return "";
}
public String  _getnextchar() throws Exception{
String _c = "";
 //BA.debugLineNum = 138;BA.debugLine="Private Sub GetNextChar As String";
 //BA.debugLineNum = 139;BA.debugLine="Dim c As String = mHtml.CharAt(Index)";
_c = BA.ObjectToString(_mhtml.charAt(_index));
 //BA.debugLineNum = 140;BA.debugLine="Index = Index + 1";
_index = (int) (_index+1);
 //BA.debugLineNum = 141;BA.debugLine="Return c";
if (true) return _c;
 //BA.debugLineNum = 142;BA.debugLine="End Sub";
return "";
}
public String  _gettextfromnode(b4j.example.minihtmlparser._htmlnode _node,int _childindex) throws Exception{
b4j.example.minihtmlparser._htmlnode _tn = null;
b4j.example.minihtmlparser._htmlattribute _at = null;
 //BA.debugLineNum = 275;BA.debugLine="Public Sub GetTextFromNode (Node As HtmlNode, Chil";
 //BA.debugLineNum = 276;BA.debugLine="Dim tn As HtmlNode = Node.Children.Get(ChildIndex";
_tn = (b4j.example.minihtmlparser._htmlnode)(_node.Children /*anywheresoftware.b4a.objects.collections.List*/ .Get(_childindex));
 //BA.debugLineNum = 277;BA.debugLine="Dim at As HtmlAttribute = tn.Attributes.Get(0)";
_at = (b4j.example.minihtmlparser._htmlattribute)(_tn.Attributes /*anywheresoftware.b4a.objects.collections.List*/ .Get((int) (0)));
 //BA.debugLineNum = 278;BA.debugLine="Return UnescapeEntities(at.Value)";
if (true) return _unescapeentities(_at.Value /*String*/ );
 //BA.debugLineNum = 279;BA.debugLine="End Sub";
return "";
}
public boolean  _ignorewhitespace() throws Exception{
boolean _ignored = false;
String _c = "";
 //BA.debugLineNum = 112;BA.debugLine="Private Sub IgnoreWhiteSpace As Boolean";
 //BA.debugLineNum = 113;BA.debugLine="Dim ignored As Boolean";
_ignored = false;
 //BA.debugLineNum = 114;BA.debugLine="Do While Index < mHtml.Length";
while (_index<_mhtml.length()) {
 //BA.debugLineNum = 115;BA.debugLine="Dim c As String = GetNextChar";
_c = _getnextchar();
 //BA.debugLineNum = 116;BA.debugLine="If WhiteSpace.IndexOf(c) = -1 Then";
if (_whitespace.indexOf(_c)==-1) { 
 //BA.debugLineNum = 117;BA.debugLine="Index = Index - 1";
_index = (int) (_index-1);
 //BA.debugLineNum = 118;BA.debugLine="Return ignored";
if (true) return _ignored;
 };
 //BA.debugLineNum = 120;BA.debugLine="ignored = True";
_ignored = __c.True;
 }
;
 //BA.debugLineNum = 122;BA.debugLine="Return ignored";
if (true) return _ignored;
 //BA.debugLineNum = 123;BA.debugLine="End Sub";
return false;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 12;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 13;BA.debugLine="VoidTags = B4XCollections.CreateSet2(Array(\"!DOCT";
_voidtags = _b4xcollections._createset2 /*b4j.example.b4xset*/ (anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)("!DOCTYPE"),(Object)("area"),(Object)("base"),(Object)("br"),(Object)("col"),(Object)("embed"),(Object)("hr"),(Object)("img"),(Object)("input"),(Object)("link"),(Object)("meta"),(Object)("param"),(Object)("source"),(Object)("track"),(Object)("wbr")}));
 //BA.debugLineNum = 15;BA.debugLine="EscapedEntitiesMap = CreateMap(\"quot\": $\"\"\"$, \"am";
_escapedentitiesmap = __c.createMap(new Object[] {(Object)("quot"),(Object)(("\"")),(Object)("amp"),(Object)("&"),(Object)("apos"),(Object)("'"),(Object)("lt"),(Object)("<"),(Object)("gt"),(Object)(">"),(Object)("nbsp"),(Object)(" ")});
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public boolean  _isnodematches(b4j.example.minihtmlparser._htmlnode _node,String _tagname,b4j.example.minihtmlparser._htmlattribute _attribute) throws Exception{
b4j.example.minihtmlparser._htmlattribute _at = null;
 //BA.debugLineNum = 258;BA.debugLine="Public Sub IsNodeMatches(Node As HtmlNode, TagName";
 //BA.debugLineNum = 259;BA.debugLine="If Node.Name = TagName Then";
if ((_node.Name /*String*/ ).equals(_tagname)) { 
 //BA.debugLineNum = 260;BA.debugLine="If Attribute <> Null And Attribute.IsInitialized";
if (_attribute!= null && _attribute.IsInitialized /*boolean*/ ) { 
 //BA.debugLineNum = 261;BA.debugLine="For Each At As HtmlAttribute In Node.Attributes";
{
final anywheresoftware.b4a.BA.IterableList group3 = _node.Attributes /*anywheresoftware.b4a.objects.collections.List*/ ;
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_at = (b4j.example.minihtmlparser._htmlattribute)(group3.Get(index3));
 //BA.debugLineNum = 262;BA.debugLine="If At.Key = Attribute.Key And At.Value = Attri";
if ((_at.Key /*String*/ ).equals(_attribute.Key /*String*/ ) && (_at.Value /*String*/ ).equals(_attribute.Value /*String*/ )) { 
 //BA.debugLineNum = 263;BA.debugLine="Return True";
if (true) return __c.True;
 };
 }
};
 }else {
 //BA.debugLineNum = 267;BA.debugLine="Return True";
if (true) return __c.True;
 };
 };
 //BA.debugLineNum = 270;BA.debugLine="Return False";
if (true) return __c.False;
 //BA.debugLineNum = 271;BA.debugLine="End Sub";
return false;
}
public boolean  _isroot(b4j.example.minihtmlparser._htmlnode _n) throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="Public Sub IsRoot(n As HtmlNode) As Boolean";
 //BA.debugLineNum = 53;BA.debugLine="Return n.Parent.IsInitialized = False";
if (true) return _n.Parent /*b4j.example.minihtmlparser._htmlnode*/ .IsInitialized /*boolean*/ ==__c.False;
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return false;
}
public boolean  _iswhitespace(String _c) throws Exception{
 //BA.debugLineNum = 125;BA.debugLine="Private Sub IsWhiteSpace (c As String) As Boolean";
 //BA.debugLineNum = 126;BA.debugLine="Return WhiteSpace.IndexOf(c) > -1";
if (true) return _whitespace.indexOf(_c)>-1;
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return false;
}
public b4j.example.minihtmlparser._htmlnode  _parse(String _html) throws Exception{
b4j.example.minihtmlparser._htmlnode _root = null;
 //BA.debugLineNum = 19;BA.debugLine="Public Sub Parse (Html As String) As HtmlNode";
 //BA.debugLineNum = 20;BA.debugLine="Index = 0";
_index = (int) (0);
 //BA.debugLineNum = 21;BA.debugLine="mHtml = Html";
_mhtml = _html;
 //BA.debugLineNum = 22;BA.debugLine="Dim root As HtmlNode = CreateHtmlNode(\"root\", NoN";
_root = _createhtmlnode("root",_nonode);
 //BA.debugLineNum = 23;BA.debugLine="ParseImpl(root)";
_parseimpl(_root);
 //BA.debugLineNum = 24;BA.debugLine="Return root";
if (true) return _root;
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return null;
}
public String  _parseattributes(b4j.example.minihtmlparser._htmlnode _parent) throws Exception{
int _start = 0;
String _s = "";
String _escapechar = "";
anywheresoftware.b4a.keywords.Regex.MatcherWrapper _m = null;
 //BA.debugLineNum = 189;BA.debugLine="Private Sub ParseAttributes (Parent As HtmlNode)";
 //BA.debugLineNum = 190;BA.debugLine="Dim start As Int = Index";
_start = _index;
 //BA.debugLineNum = 191;BA.debugLine="ReadUntil(\">\")";
_readuntil(">");
 //BA.debugLineNum = 192;BA.debugLine="Dim s As String = mHtml.SubString2(start, Index -";
_s = _mhtml.substring(_start,(int) (_index-1));
 //BA.debugLineNum = 193;BA.debugLine="For Each EscapeChar As String In Array(\"'\", $\"\"\"$";
{
final Object[] group4 = new Object[]{(Object)("'"),(Object)(("\""))};
final int groupLen4 = group4.length
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_escapechar = BA.ObjectToString(group4[index4]);
 //BA.debugLineNum = 194;BA.debugLine="Dim m As Matcher = Regex.Matcher($\"(\\w+)\\s*=\\s*\\";
_m = new anywheresoftware.b4a.keywords.Regex.MatcherWrapper();
_m = __c.Regex.Matcher(("(\\w+)\\s*=\\s*\\"+__c.SmartStringFormatter("",(Object)(_escapechar))+"([^"+__c.SmartStringFormatter("",(Object)(_escapechar))+"]+)\\"+__c.SmartStringFormatter("",(Object)(_escapechar))+""),_s);
 //BA.debugLineNum = 195;BA.debugLine="Do While m.Find";
while (_m.Find()) {
 //BA.debugLineNum = 196;BA.debugLine="Parent.Attributes.Add(CreateHtmlAttribute(m.Gro";
_parent.Attributes /*anywheresoftware.b4a.objects.collections.List*/ .Add((Object)(_createhtmlattribute(_m.Group((int) (1)),_m.Group((int) (2)))));
 }
;
 }
};
 //BA.debugLineNum = 199;BA.debugLine="End Sub";
return "";
}
public String  _parsecomment(b4j.example.minihtmlparser._htmlnode _n) throws Exception{
int _start = 0;
 //BA.debugLineNum = 180;BA.debugLine="Private Sub ParseComment (n As HtmlNode)";
 //BA.debugLineNum = 181;BA.debugLine="n.Closed = True";
_n.Closed /*boolean*/  = __c.True;
 //BA.debugLineNum = 182;BA.debugLine="n.Name = \"comment\"";
_n.Name /*String*/  = "comment";
 //BA.debugLineNum = 183;BA.debugLine="Dim start As Int = Index";
_start = _index;
 //BA.debugLineNum = 184;BA.debugLine="ReadUntil(\"-->\")";
_readuntil("-->");
 //BA.debugLineNum = 185;BA.debugLine="n.Attributes.Add(CreateHtmlAttribute(\"value\", mHt";
_n.Attributes /*anywheresoftware.b4a.objects.collections.List*/ .Add((Object)(_createhtmlattribute("value",_mhtml.substring(_start,(int) (_index-1)))));
 //BA.debugLineNum = 186;BA.debugLine="ReadUntil(\">\")";
_readuntil(">");
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
return "";
}
public String  _parseimpl(b4j.example.minihtmlparser._htmlnode _parent) throws Exception{
boolean _whitespaceignored = false;
String _c = "";
b4j.example.minihtmlparser._htmlnode _textnode = null;
 //BA.debugLineNum = 27;BA.debugLine="Private Sub ParseImpl (Parent As HtmlNode)";
 //BA.debugLineNum = 28;BA.debugLine="Do While Index < mHtml.Length";
while (_index<_mhtml.length()) {
 //BA.debugLineNum = 29;BA.debugLine="Dim WhiteSpaceIgnored As Boolean = IgnoreWhiteSp";
_whitespaceignored = _ignorewhitespace();
 //BA.debugLineNum = 30;BA.debugLine="If Index >= mHtml.Length Then Exit";
if (_index>=_mhtml.length()) { 
if (true) break;};
 //BA.debugLineNum = 31;BA.debugLine="Dim c As String = GetNextChar";
_c = _getnextchar();
 //BA.debugLineNum = 32;BA.debugLine="If c = \"<\" Then";
if ((_c).equals("<")) { 
 //BA.debugLineNum = 33;BA.debugLine="If PeekNextChar = \"/\" Then";
if ((_peeknextchar()).equals("/")) { 
 //BA.debugLineNum = 34;BA.debugLine="CloseElement(Parent)";
_closeelement(_parent);
 //BA.debugLineNum = 35;BA.debugLine="If IsRoot(Parent) = False Then Return";
if (_isroot(_parent)==__c.False) { 
if (true) return "";};
 }else {
 //BA.debugLineNum = 37;BA.debugLine="If WhiteSpaceIgnored Then";
if (_whitespaceignored) { 
 //BA.debugLineNum = 38;BA.debugLine="Dim TextNode As HtmlNode = CreateHtmlNode(\"te";
_textnode = _createhtmlnode("text",_parent);
 //BA.debugLineNum = 39;BA.debugLine="TextNode.Attributes.Add(CreateHtmlAttribute(\"";
_textnode.Attributes /*anywheresoftware.b4a.objects.collections.List*/ .Add((Object)(_createhtmlattribute("value"," ")));
 //BA.debugLineNum = 40;BA.debugLine="Parent.Children.Add(TextNode)";
_parent.Children /*anywheresoftware.b4a.objects.collections.List*/ .Add((Object)(_textnode));
 };
 //BA.debugLineNum = 42;BA.debugLine="Parent.Children.Add(ParseTagStart(Parent))";
_parent.Children /*anywheresoftware.b4a.objects.collections.List*/ .Add((Object)(_parsetagstart(_parent)));
 //BA.debugLineNum = 43;BA.debugLine="If Parent.Closed And IsRoot(Parent) = False Th";
if (_parent.Closed /*boolean*/  && _isroot(_parent)==__c.False) { 
if (true) return "";};
 };
 }else {
 //BA.debugLineNum = 47;BA.debugLine="Parent.Children.Add(CreateTextNode(Parent, Whit";
_parent.Children /*anywheresoftware.b4a.objects.collections.List*/ .Add((Object)(_createtextnode(_parent,_whitespaceignored)));
 };
 }
;
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public String  _parserawtextnode(b4j.example.minihtmlparser._htmlnode _n) throws Exception{
int _start = 0;
 //BA.debugLineNum = 95;BA.debugLine="Private Sub ParseRawTextNode(n As HtmlNode)";
 //BA.debugLineNum = 96;BA.debugLine="Dim start As Int = Index";
_start = _index;
 //BA.debugLineNum = 97;BA.debugLine="ReadUntil($\"</${n.Name}>\"$)";
_readuntil(("</"+__c.SmartStringFormatter("",(Object)(_n.Name /*String*/ ))+">"));
 //BA.debugLineNum = 98;BA.debugLine="n.Attributes.Add(CreateHtmlAttribute(\"value\", mHt";
_n.Attributes /*anywheresoftware.b4a.objects.collections.List*/ .Add((Object)(_createhtmlattribute("value",_mhtml.substring(_start,(int) (_index-1)))));
 //BA.debugLineNum = 99;BA.debugLine="ReadUntil(\">\")";
_readuntil(">");
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
return "";
}
public b4j.example.minihtmlparser._htmlnode  _parsetagstart(b4j.example.minihtmlparser._htmlnode _parent) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
b4j.example.minihtmlparser._htmlnode _node = null;
String _c = "";
 //BA.debugLineNum = 144;BA.debugLine="Private Sub ParseTagStart (Parent As HtmlNode) As";
 //BA.debugLineNum = 145;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 146;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 147;BA.debugLine="Dim node As HtmlNode = CreateHtmlNode(\"\", Parent)";
_node = _createhtmlnode("",_parent);
 //BA.debugLineNum = 148;BA.debugLine="Do While True";
while (__c.True) {
 //BA.debugLineNum = 149;BA.debugLine="Dim c As String = GetNextChar";
_c = _getnextchar();
 //BA.debugLineNum = 150;BA.debugLine="If c = \">\" Then";
if ((_c).equals(">")) { 
 //BA.debugLineNum = 151;BA.debugLine="If PeekPrevChar(2) = \"/\" Then";
if ((_peekprevchar((int) (2))).equals("/")) { 
 //BA.debugLineNum = 152;BA.debugLine="sb.Remove(sb.Length - 1, sb.Length)";
_sb.Remove((int) (_sb.getLength()-1),_sb.getLength());
 //BA.debugLineNum = 153;BA.debugLine="node.Closed = True";
_node.Closed /*boolean*/  = __c.True;
 };
 //BA.debugLineNum = 155;BA.debugLine="node.Name = sb.ToString";
_node.Name /*String*/  = _sb.ToString();
 //BA.debugLineNum = 156;BA.debugLine="Exit";
if (true) break;
 }else if(_iswhitespace(_c)) { 
 //BA.debugLineNum = 158;BA.debugLine="node.Name = sb.ToString";
_node.Name /*String*/  = _sb.ToString();
 //BA.debugLineNum = 159;BA.debugLine="If node.Name = \"!--\" Then";
if ((_node.Name /*String*/ ).equals("!--")) { 
 //BA.debugLineNum = 160;BA.debugLine="ParseComment (node)";
_parsecomment(_node);
 }else {
 //BA.debugLineNum = 162;BA.debugLine="ParseAttributes(node)";
_parseattributes(_node);
 };
 //BA.debugLineNum = 164;BA.debugLine="Exit";
if (true) break;
 }else {
 //BA.debugLineNum = 166;BA.debugLine="sb.Append(c)";
_sb.Append(_c);
 };
 }
;
 //BA.debugLineNum = 169;BA.debugLine="If VoidTags.Contains(node.Name) Then node.Closed";
if (_voidtags._contains /*boolean*/ ((Object)(_node.Name /*String*/ ))) { 
_node.Closed /*boolean*/  = __c.True;};
 //BA.debugLineNum = 170;BA.debugLine="If node.Closed = False Then";
if (_node.Closed /*boolean*/ ==__c.False) { 
 //BA.debugLineNum = 171;BA.debugLine="If node.Name = \"script\" Or node.Name = \"style\" T";
if ((_node.Name /*String*/ ).equals("script") || (_node.Name /*String*/ ).equals("style")) { 
 //BA.debugLineNum = 172;BA.debugLine="ParseRawTextNode(node)";
_parserawtextnode(_node);
 }else {
 //BA.debugLineNum = 174;BA.debugLine="ParseImpl(node)";
_parseimpl(_node);
 };
 };
 //BA.debugLineNum = 177;BA.debugLine="Return node";
if (true) return _node;
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return null;
}
public String  _peeknextchar() throws Exception{
 //BA.debugLineNum = 133;BA.debugLine="Private Sub PeekNextChar As String";
 //BA.debugLineNum = 134;BA.debugLine="If Index >= mHtml.Length Then Return \"\"";
if (_index>=_mhtml.length()) { 
if (true) return "";};
 //BA.debugLineNum = 135;BA.debugLine="Return mHtml.CharAt(Index)";
if (true) return BA.ObjectToString(_mhtml.charAt(_index));
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
return "";
}
public String  _peekprevchar(int _offset) throws Exception{
 //BA.debugLineNum = 129;BA.debugLine="Private Sub PeekPrevChar (offset As Int) As String";
 //BA.debugLineNum = 130;BA.debugLine="Return mHtml.CharAt(Index - offset)";
if (true) return BA.ObjectToString(_mhtml.charAt((int) (_index-_offset)));
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return "";
}
public String  _printnode(b4j.example.minihtmlparser._htmlnode _node) throws Exception{
 //BA.debugLineNum = 219;BA.debugLine="Public Sub PrintNode (node As HtmlNode)";
 //BA.debugLineNum = 220;BA.debugLine="PrintNodeHelper(node, \"\")";
_printnodehelper(_node,"");
 //BA.debugLineNum = 221;BA.debugLine="End Sub";
return "";
}
public String  _printnodehelper(b4j.example.minihtmlparser._htmlnode _node,String _indent) throws Exception{
b4j.example.minihtmlparser._htmlattribute _attribute = null;
b4j.example.minihtmlparser._htmlnode _child = null;
 //BA.debugLineNum = 223;BA.debugLine="Private Sub PrintNodeHelper (node As HtmlNode, Ind";
 //BA.debugLineNum = 224;BA.debugLine="Log($\"${Indent}*** ${node.Name} ***\"$)";
__c.LogImpl("96160385",(""+__c.SmartStringFormatter("",(Object)(_indent))+"*** "+__c.SmartStringFormatter("",(Object)(_node.Name /*String*/ ))+" ***"),0);
 //BA.debugLineNum = 225;BA.debugLine="For Each attribute As HtmlAttribute In node.Attri";
{
final anywheresoftware.b4a.BA.IterableList group2 = _node.Attributes /*anywheresoftware.b4a.objects.collections.List*/ ;
final int groupLen2 = group2.getSize()
;int index2 = 0;
;
for (; index2 < groupLen2;index2++){
_attribute = (b4j.example.minihtmlparser._htmlattribute)(group2.Get(index2));
 //BA.debugLineNum = 226;BA.debugLine="Log($\"${Indent}|${attribute.Key}: ${attribute.Va";
__c.LogImpl("96160387",(""+__c.SmartStringFormatter("",(Object)(_indent))+"|"+__c.SmartStringFormatter("",(Object)(_attribute.Key /*String*/ ))+": "+__c.SmartStringFormatter("",(Object)(_attribute.Value /*String*/ ))+"|"),0);
 }
};
 //BA.debugLineNum = 228;BA.debugLine="For Each child As HtmlNode In node.Children";
{
final anywheresoftware.b4a.BA.IterableList group5 = _node.Children /*anywheresoftware.b4a.objects.collections.List*/ ;
final int groupLen5 = group5.getSize()
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_child = (b4j.example.minihtmlparser._htmlnode)(group5.Get(index5));
 //BA.debugLineNum = 229;BA.debugLine="PrintNodeHelper(child, Indent & \" \")";
_printnodehelper(_child,_indent+" ");
 }
};
 //BA.debugLineNum = 231;BA.debugLine="End Sub";
return "";
}
public String  _readuntil(String _s) throws Exception{
int _i = 0;
 //BA.debugLineNum = 102;BA.debugLine="Private Sub ReadUntil (s As String)";
 //BA.debugLineNum = 103;BA.debugLine="Dim i As Int = mHtml.IndexOf2(s, Index)";
_i = _mhtml.indexOf(_s,_index);
 //BA.debugLineNum = 104;BA.debugLine="If i = -1 Then";
if (_i==-1) { 
 //BA.debugLineNum = 106;BA.debugLine="Index = mHtml.Length";
_index = _mhtml.length();
 }else {
 //BA.debugLineNum = 108;BA.debugLine="Index = i + 1";
_index = (int) (_i+1);
 };
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
public String  _unescapeentities(String _input) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _lastmatchend = 0;
anywheresoftware.b4a.keywords.Regex.MatcherWrapper _m = null;
String _capture = "";
int _currentstart = 0;
 //BA.debugLineNum = 289;BA.debugLine="Public Sub UnescapeEntities(Input As String) As St";
 //BA.debugLineNum = 290;BA.debugLine="If Input.Contains(\"&\") = False Then Return Input";
if (_input.contains("&")==__c.False) { 
if (true) return _input;};
 //BA.debugLineNum = 291;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 292;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 293;BA.debugLine="Dim lastMatchEnd As Int = 0";
_lastmatchend = (int) (0);
 //BA.debugLineNum = 294;BA.debugLine="Dim m As Matcher = Regex.Matcher(\"&([a-z0-9]+|#[0";
_m = new anywheresoftware.b4a.keywords.Regex.MatcherWrapper();
_m = __c.Regex.Matcher("&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});",_input);
 //BA.debugLineNum = 295;BA.debugLine="Do While m.Find";
while (_m.Find()) {
 //BA.debugLineNum = 296;BA.debugLine="Dim capture As String = m.Group(1)";
_capture = _m.Group((int) (1));
 //BA.debugLineNum = 297;BA.debugLine="Dim currentStart As Int = m.GetStart(0)";
_currentstart = _m.GetStart((int) (0));
 //BA.debugLineNum = 298;BA.debugLine="sb.Append(Input.SubString2(lastMatchEnd, current";
_sb.Append(_input.substring(_lastmatchend,_currentstart));
 //BA.debugLineNum = 299;BA.debugLine="lastMatchEnd = m.GetEnd(0)";
_lastmatchend = _m.GetEnd((int) (0));
 //BA.debugLineNum = 300;BA.debugLine="If EscapedEntitiesMap.ContainsKey(capture) Then";
if (_escapedentitiesmap.ContainsKey((Object)(_capture))) { 
 //BA.debugLineNum = 301;BA.debugLine="sb.Append(EscapedEntitiesMap.Get(m.Group(1)))";
_sb.Append(BA.ObjectToString(_escapedentitiesmap.Get((Object)(_m.Group((int) (1))))));
 }else if(_capture.startsWith("#x")) { 
 //BA.debugLineNum = 303;BA.debugLine="sb.Append(Chr(Bit.ParseInt(capture.SubString(2)";
_sb.Append(BA.ObjectToString(__c.Chr(__c.Bit.ParseInt(_capture.substring((int) (2)),(int) (16)))));
 }else if(_capture.startsWith("#")) { 
 //BA.debugLineNum = 305;BA.debugLine="sb.Append(Chr(capture.SubString(1)))";
_sb.Append(BA.ObjectToString(__c.Chr((int)(Double.parseDouble(_capture.substring((int) (1)))))));
 }else {
 //BA.debugLineNum = 307;BA.debugLine="Log(\"Missing entity: \" & m.Group(1))";
__c.LogImpl("96553618","Missing entity: "+_m.Group((int) (1)),0);
 };
 }
;
 //BA.debugLineNum = 310;BA.debugLine="If lastMatchEnd < Input.Length Then sb.Append(Inp";
if (_lastmatchend<_input.length()) { 
_sb.Append(_input.substring(_lastmatchend));};
 //BA.debugLineNum = 311;BA.debugLine="Return sb.ToString";
if (true) return _sb.ToString();
 //BA.debugLineNum = 312;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
