package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 800, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button2 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textarea1 = null;
public static b4j.example.minihtmlparser _htmlparser = null;
public static anywheresoftware.b4a.objects.collections.List _lstdata = null;
public static anywheresoftware.b4j.objects.TableViewWrapper _tableview1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textfield1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _textfield2 = null;
public static b4j.example.b4xcollections _b4xcollections = null;
public static b4j.example.httputils2service _httputils2service = null;
public static class _stock{
public boolean IsInitialized;
public String td1;
public String td2;
public String td3;
public String td4;
public void Initialize() {
IsInitialized = true;
td1 = "";
td2 = "";
td3 = "";
td4 = "";
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 27;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 28;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 29;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 33;BA.debugLine="TableView1.SetColumns(Array As String(\"交易日\", \"成交量";
_tableview1.SetColumns(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"交易日","成交量","成交金額","收盤價"}));
 //BA.debugLineNum = 34;BA.debugLine="TextField1.Text = \"2049\"";
_textfield1.setText("2049");
 //BA.debugLineNum = 35;BA.debugLine="TextField2.Text = \"20220301\"";
_textfield2.setText("20220301");
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public static void  _button1_click() throws Exception{
ResumableSub_Button1_Click rsub = new ResumableSub_Button1_Click(null);
rsub.resume(ba, null);
}
public static class ResumableSub_Button1_Click extends BA.ResumableSub {
public ResumableSub_Button1_Click(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 41;BA.debugLine="TextArea1.Text = \"\"";
parent._textarea1.setText("");
 //BA.debugLineNum = 43;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
 //BA.debugLineNum = 44;BA.debugLine="j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",main.getObject());
 //BA.debugLineNum = 45;BA.debugLine="j.Download($\"https://www.twse.com.tw/exchangeRepo";
_j._download /*String*/ (("https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=html&date="+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(parent._textfield2.getText()))+"$&stockNo="+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(parent._textfield1.getText()))+" "));
 //BA.debugLineNum = 46;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 47;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 48;BA.debugLine="Log(j.GetString)";
anywheresoftware.b4a.keywords.Common.LogImpl("0131081",_j._getstring /*String*/ (),0);
 //BA.debugLineNum = 50;BA.debugLine="TextArea1.Text = j.GetString";
parent._textarea1.setText(_j._getstring /*String*/ ());
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 52;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _jobdone(b4j.example.httpjob _j) throws Exception{
}
public static void  _button2_click() throws Exception{
ResumableSub_Button2_Click rsub = new ResumableSub_Button2_Click(null);
rsub.resume(ba, null);
}
public static class ResumableSub_Button2_Click extends BA.ResumableSub {
public ResumableSub_Button2_Click(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
anywheresoftware.b4a.keywords.Common.ResumableSubWrapper _rs = null;
String _result = "";
b4j.example.minihtmlparser._htmlnode _root = null;
b4j.example.minihtmlparser._htmlnode _table = null;
b4j.example.minihtmlparser._htmlnode _tbody = null;
b4j.example.minihtmlparser._htmlnode _tr = null;
anywheresoftware.b4a.objects.collections.List _tds = null;
String _td1 = "";
String _td2 = "";
String _td3 = "";
String _td4 = "";
b4j.example.main._stock _s1 = null;
Object[] _row = null;
anywheresoftware.b4a.BA.IterableList group14;
int index14;
int groupLen14;
anywheresoftware.b4a.BA.IterableList group33;
int index33;
int groupLen33;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 60;BA.debugLine="TextArea1.Text = \"\"";
parent._textarea1.setText("");
 //BA.debugLineNum = 61;BA.debugLine="lstData.Initialize";
parent._lstdata.Initialize();
 //BA.debugLineNum = 62;BA.debugLine="TableView1.Items.Clear";
parent._tableview1.getItems().Clear();
 //BA.debugLineNum = 66;BA.debugLine="Dim rs As ResumableSub = GetHtmlPage($\"https://ww";
_rs = new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper();
_rs = _gethtmlpage(("https://www.twse.com.tw/exchangeReport/STOCK_DAY?response=html&date="+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(parent._textfield2.getText()))+"$&stockNo="+anywheresoftware.b4a.keywords.Common.SmartStringFormatter("",(Object)(parent._textfield1.getText()))+" "));
 //BA.debugLineNum = 67;BA.debugLine="Wait For(rs) Complete (Result As String)";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _rs);
this.state = 25;
return;
case 25:
//C
this.state = 1;
_result = (String) result[0];
;
 //BA.debugLineNum = 70;BA.debugLine="TextArea1.Text = Result";
parent._textarea1.setText(_result);
 //BA.debugLineNum = 74;BA.debugLine="HtmlParser.Initialize";
parent._htmlparser._initialize /*String*/ (ba);
 //BA.debugLineNum = 76;BA.debugLine="Dim root As HtmlNode = HtmlParser.Parse(TextArea1";
_root = parent._htmlparser._parse /*b4j.example.minihtmlparser._htmlnode*/ (parent._textarea1.getText());
 //BA.debugLineNum = 83;BA.debugLine="Dim Table As HtmlNode = HtmlParser.FindNode(root,";
_table = parent._htmlparser._findnode /*b4j.example.minihtmlparser._htmlnode*/ (_root,"table",(b4j.example.minihtmlparser._htmlattribute)(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 84;BA.debugLine="If Table.IsInitialized Then";
if (true) break;

case 1:
//if
this.state = 20;
if (_table.IsInitialized /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 19;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 86;BA.debugLine="Dim tbody As HtmlNode = HtmlParser.FindNode(Tabl";
_tbody = parent._htmlparser._findnode /*b4j.example.minihtmlparser._htmlnode*/ (_table,"tbody",(b4j.example.minihtmlparser._htmlattribute)(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 87;BA.debugLine="If tbody.IsInitialized Then";
if (true) break;

case 4:
//if
this.state = 17;
if (_tbody.IsInitialized /*boolean*/ ) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 89;BA.debugLine="HtmlParser.PrintNode(tbody.Children.Get(1))";
parent._htmlparser._printnode /*String*/ ((b4j.example.minihtmlparser._htmlnode)(_tbody.Children /*anywheresoftware.b4a.objects.collections.List*/ .Get((int) (1))));
 //BA.debugLineNum = 90;BA.debugLine="For Each tr As HtmlNode In HtmlParser.FindDirec";
if (true) break;

case 7:
//for
this.state = 16;
group14 = parent._htmlparser._finddirectnodes /*anywheresoftware.b4a.objects.collections.List*/ (_tbody,"tr",(b4j.example.minihtmlparser._htmlattribute)(anywheresoftware.b4a.keywords.Common.Null));
index14 = 0;
groupLen14 = group14.getSize();
this.state = 26;
if (true) break;

case 26:
//C
this.state = 16;
if (index14 < groupLen14) {
this.state = 9;
_tr = (b4j.example.minihtmlparser._htmlnode)(group14.Get(index14));}
if (true) break;

case 27:
//C
this.state = 26;
index14++;
if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 91;BA.debugLine="Dim tds As List = HtmlParser.FindDirectNodes(t";
_tds = new anywheresoftware.b4a.objects.collections.List();
_tds = parent._htmlparser._finddirectnodes /*anywheresoftware.b4a.objects.collections.List*/ (_tr,"td",(b4j.example.minihtmlparser._htmlattribute)(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 93;BA.debugLine="Try";
if (true) break;

case 10:
//try
this.state = 15;
this.catchState = 14;
this.state = 12;
if (true) break;

case 12:
//C
this.state = 15;
this.catchState = 14;
 //BA.debugLineNum = 94;BA.debugLine="Dim td1 As String = HtmlParser.GetTextFromNod";
_td1 = parent._htmlparser._gettextfromnode /*String*/ ((b4j.example.minihtmlparser._htmlnode)(_tds.Get((int) (0))),(int) (0));
 //BA.debugLineNum = 97;BA.debugLine="Dim td2 As String = HtmlParser.GetTextFromNod";
_td2 = parent._htmlparser._gettextfromnode /*String*/ ((b4j.example.minihtmlparser._htmlnode)(_tds.Get((int) (1))),(int) (0));
 //BA.debugLineNum = 100;BA.debugLine="Dim td3 As String = HtmlParser.GetTextFromNod";
_td3 = parent._htmlparser._gettextfromnode /*String*/ ((b4j.example.minihtmlparser._htmlnode)(_tds.Get((int) (2))),(int) (0));
 //BA.debugLineNum = 103;BA.debugLine="Dim td4 As String = HtmlParser.GetTextFromNod";
_td4 = parent._htmlparser._gettextfromnode /*String*/ ((b4j.example.minihtmlparser._htmlnode)(_tds.Get((int) (6))),(int) (0));
 //BA.debugLineNum = 108;BA.debugLine="lstData.Add(CreateStock(td1,td2,td3,td4))";
parent._lstdata.Add((Object)(_createstock(_td1,_td2,_td3,_td4)));
 if (true) break;

case 14:
//C
this.state = 15;
this.catchState = 0;
 //BA.debugLineNum = 111;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("08781878",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 if (true) break;
if (true) break;

case 15:
//C
this.state = 27;
this.catchState = 0;
;
 if (true) break;
if (true) break;

case 16:
//C
this.state = 17;
;
 if (true) break;

case 17:
//C
this.state = 20;
;
 if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 117;BA.debugLine="Log(\"網頁 not found!!!\")";
anywheresoftware.b4a.keywords.Common.LogImpl("08781884","網頁 not found!!!",0);
 //BA.debugLineNum = 118;BA.debugLine="TextArea1.Text = \"網頁 not found!!!\"";
parent._textarea1.setText("網頁 not found!!!");
 if (true) break;

case 20:
//C
this.state = 21;
;
 //BA.debugLineNum = 120;BA.debugLine="Log(\"***********************\")";
anywheresoftware.b4a.keywords.Common.LogImpl("08781887","***********************",0);
 //BA.debugLineNum = 124;BA.debugLine="TableView1.SetColumns(Array As String(\"交易日\", \"成交量";
parent._tableview1.SetColumns(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"交易日","成交量","成交金額","收盤價"}));
 //BA.debugLineNum = 128;BA.debugLine="For Each s1 As stock In lstData";
if (true) break;

case 21:
//for
this.state = 24;
group33 = parent._lstdata;
index33 = 0;
groupLen33 = group33.getSize();
this.state = 28;
if (true) break;

case 28:
//C
this.state = 24;
if (index33 < groupLen33) {
this.state = 23;
_s1 = (b4j.example.main._stock)(group33.Get(index33));}
if (true) break;

case 29:
//C
this.state = 28;
index33++;
if (true) break;

case 23:
//C
this.state = 29;
 //BA.debugLineNum = 134;BA.debugLine="Dim Row() As Object = Array (s1.td1, s1.td2, s1.";
_row = new Object[]{(Object)(_s1.td1 /*String*/ ),(Object)(_s1.td2 /*String*/ ),(Object)(_s1.td3 /*String*/ ),(Object)(_s1.td4 /*String*/ )};
 //BA.debugLineNum = 135;BA.debugLine="TableView1.Items.Add(Row)";
parent._tableview1.getItems().Add((Object)(_row));
 if (true) break;
if (true) break;

case 24:
//C
this.state = -1;
;
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public static void  _complete(String _result) throws Exception{
}
public static b4j.example.main._stock  _createstock(String _td1,String _td2,String _td3,String _td4) throws Exception{
b4j.example.main._stock _s1 = null;
 //BA.debugLineNum = 147;BA.debugLine="Public Sub CreateStock (td1 As String, td2 As Stri";
 //BA.debugLineNum = 148;BA.debugLine="Dim s1 As stock";
_s1 = new b4j.example.main._stock();
 //BA.debugLineNum = 149;BA.debugLine="s1.Initialize";
_s1.Initialize();
 //BA.debugLineNum = 150;BA.debugLine="s1.td1 = td1";
_s1.td1 /*String*/  = _td1;
 //BA.debugLineNum = 151;BA.debugLine="s1.td2 = td2";
_s1.td2 /*String*/  = _td2;
 //BA.debugLineNum = 152;BA.debugLine="s1.td3 = td3";
_s1.td3 /*String*/  = _td3;
 //BA.debugLineNum = 153;BA.debugLine="s1.td4 = td4";
_s1.td4 /*String*/  = _td4;
 //BA.debugLineNum = 155;BA.debugLine="Return s1";
if (true) return _s1;
 //BA.debugLineNum = 156;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _gethtmlpage(String _url) throws Exception{
ResumableSub_GetHtmlPage rsub = new ResumableSub_GetHtmlPage(null,_url);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_GetHtmlPage extends BA.ResumableSub {
public ResumableSub_GetHtmlPage(b4j.example.main parent,String _url) {
this.parent = parent;
this._url = _url;
}
b4j.example.main parent;
String _url;
String _p = "";
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 160;BA.debugLine="Dim p As String";
_p = "";
 //BA.debugLineNum = 161;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
 //BA.debugLineNum = 163;BA.debugLine="p = \"\"";
_p = "";
 //BA.debugLineNum = 164;BA.debugLine="j.Initialize(\"\", Me)";
_j._initialize /*String*/ (ba,"",main.getObject());
 //BA.debugLineNum = 165;BA.debugLine="j.Download(url)";
_j._download /*String*/ (_url);
 //BA.debugLineNum = 166;BA.debugLine="Wait For (j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 167;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 169;BA.debugLine="p=j.GetString";
_p = _j._getstring /*String*/ ();
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 171;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 175;BA.debugLine="Return p";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_p));return;};
 //BA.debugLineNum = 176;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
b4xcollections._process_globals();
httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 10;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Private Button2 As B4XView";
_button2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private TextArea1 As B4XView";
_textarea1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private HtmlParser As MiniHtmlParser";
_htmlparser = new b4j.example.minihtmlparser();
 //BA.debugLineNum = 17;BA.debugLine="Private lstData As List";
_lstdata = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 18;BA.debugLine="Type stock (td1 As String, td2 As String, td3 As";
;
 //BA.debugLineNum = 21;BA.debugLine="Private TableView1 As TableView";
_tableview1 = new anywheresoftware.b4j.objects.TableViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private TextField1 As B4XView";
_textfield1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private TextField2 As B4XView";
_textfield2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
}
